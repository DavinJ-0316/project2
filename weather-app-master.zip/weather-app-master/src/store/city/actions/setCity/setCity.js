import { SET_CITY } from '../../type';

export default (city) => ({
  type: SET_CITY,
  city,
});
