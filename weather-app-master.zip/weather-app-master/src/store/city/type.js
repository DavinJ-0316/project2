export const SET_CITY = 'SET_CITY';
