export { default } from './getWeathers';
