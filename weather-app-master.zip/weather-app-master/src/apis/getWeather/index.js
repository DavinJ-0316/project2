export { default } from './getWeather';
