export { default } from './Temperature';
