export { default } from './OpenWeatherMap';
